//
//  JokerPresenter.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class JokerPresenter: ViewToPresenterProtocol {
    
    var view: PresenterToViewProtocol?
    var interactor: PresentorToInteractorProtocol?
    var router: PresenterToRouterProtocol?
    
    func startFetchingJoke() {
        interactor?.fetchRandomJoke()
    }
}

extension JokerPresenter: InteractorToPresenterProtocol {
    func jokeFetched(joke: JokerModel) {
        view?.showRandomJoke(joke: joke)
    }
    
    func jokerFetchedFailed() {
        view?.showError()
    }
    

}
