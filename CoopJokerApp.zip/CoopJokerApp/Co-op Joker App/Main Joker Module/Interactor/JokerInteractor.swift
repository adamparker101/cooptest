//
//  JokerInteractor.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import Foundation
import Alamofire

class JokerInteractor: PresentorToInteractorProtocol {
    
    public static let URL = "http://api.icndb.com/jokes/random/"
    public static let URL_TEXT = "http://api.icndb.com/jokes/random?firstName=John&amp;lastName=Doe"

    var presenter: InteractorToPresenterProtocol?
    
    func fetchRandomJoke() {
        
        Alamofire.request(JokerInteractor.URL).response { response in
                   if(response.response?.statusCode == 200){
                       guard let data = response.data else { return }
                       do {
                           let decoder = JSONDecoder()
                           let jokeResponse = try decoder.decode(JokerModel.self, from: data)
                           self.presenter?.jokeFetched(joke: jokeResponse)
                       } catch let error {
                           print(error)
                       }
                   }
                   else {
                       self.presenter?.jokerFetchedFailed()
                   }
               }
    }
    
    func fetchTextFieldJoke() {
          Alamofire.request(JokerInteractor.URL_TEXT).response { response in
              if(response.response?.statusCode == 200){
                  guard let data = response.data else { return }
                  do {
                      let decoder = JSONDecoder()
                      let jokeResponse = try decoder.decode(JokerModel.self, from: data)
                      self.presenter?.jokeFetched(joke: jokeResponse)
                  } catch let error {
                      print(error)
                  }
              }
              else {
                  self.presenter?.jokerFetchedFailed()
              }
          }
      }
    
}
