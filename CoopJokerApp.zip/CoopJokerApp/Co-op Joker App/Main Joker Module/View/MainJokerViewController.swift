//
//  MainJokerViewController.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class MainJokerViewController: UIViewController {

    var presenter: ViewToPresenterProtocol?
    var multiPresenter: MultiJokerViewToPresenterProtocol?

    @IBOutlet weak var ranDomJokeBtn: UIButton!
    @IBOutlet weak var textInputBtn: UIButton!
    @IBOutlet weak var neverEndingBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        styleAllBtns(Btn: ranDomJokeBtn)
        styleAllBtns(Btn: textInputBtn)
        styleAllBtns(Btn: neverEndingBtn)
    }
    
    func styleAllBtns(Btn : UIButton)
    {
        Btn.layer.cornerRadius = 10
        Btn.clipsToBounds = true
    }
    
    @IBAction func randomJokeAction(_ sender: Any) {
        presenter?.startFetchingJoke()
    }
    
    @IBAction func textInputJokeAction(_ sender: Any) {
        let nextView = textInputJokeRouter.createModule()
        self.navigationController?.pushViewController(nextView, animated: true)
    }
    
    @IBAction func neverEndingJokeAction(_ sender: Any) {
        
        let nextView = MultiJokerRouter.createModuleMulti()
       self.navigationController?.pushViewController(nextView, animated: true)
    }
   
}

extension MainJokerViewController: PresenterToViewProtocol {
    func showRandomJoke(joke: JokerModel) {
        let alert = UIAlertController(title: "Random joke", message: joke.value?.joke , preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Thanks", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func showError() {
        let alert = UIAlertController(title: "Alert", message: "Problem Fetching Jokes", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    

}
