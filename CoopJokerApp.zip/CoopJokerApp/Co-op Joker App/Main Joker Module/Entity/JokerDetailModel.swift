//
//  JokerDetailModel.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import Foundation

class JokerDetailModel: Codable {

    let id: Int?
    let joke: String?
    
    enum CodingKeys: String, CodingKey {
           case id
           case joke
    }
}
