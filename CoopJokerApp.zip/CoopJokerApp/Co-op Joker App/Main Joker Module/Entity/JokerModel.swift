//
//  JokerModel.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import Foundation

class JokerModel: Codable {

    let type: String?
    let value: JokerDetailModel?
    
    enum CodingKeys: String, CodingKey {
           case type
           case value
    }
}
