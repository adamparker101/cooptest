//
//  JokerRouter.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class JokerRouter: PresenterToRouterProtocol {

    class func createModule() ->UIViewController{
        
          let view = mainstoryboard.instantiateViewController(withIdentifier: "MainJokerViewController") as? MainJokerViewController

              let presenter: ViewToPresenterProtocol & InteractorToPresenterProtocol = JokerPresenter()
              let interactor: PresentorToInteractorProtocol = JokerInteractor()
              let router: PresenterToRouterProtocol = JokerRouter()
              
              view?.presenter = presenter
              presenter.view = view
              presenter.router = router
              presenter.interactor = interactor
              interactor.presenter = presenter
              
              let navigationController = UINavigationController(rootViewController: view!)

        return navigationController;

      }
      
      static var mainstoryboard: UIStoryboard{
          return UIStoryboard(name:"Main",bundle: Bundle.main)
      }
    
}
