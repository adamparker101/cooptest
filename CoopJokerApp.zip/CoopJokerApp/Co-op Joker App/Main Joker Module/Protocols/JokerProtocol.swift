//
//  JokerProtocol.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit
import Foundation

protocol PresenterToViewProtocol: class {
    func showRandomJoke(joke: JokerModel)
    func showError()
}

protocol InteractorToPresenterProtocol: class {
    func jokeFetched(joke: JokerModel)
    func jokerFetchedFailed()
}

protocol PresentorToInteractorProtocol: class {
    var presenter: InteractorToPresenterProtocol? {get set}
    func fetchRandomJoke()
}

protocol ViewToPresenterProtocol: class {
    var view: PresenterToViewProtocol? {get set}
    var interactor: PresentorToInteractorProtocol? {get set}
    var router: PresenterToRouterProtocol? {get set}
    func startFetchingJoke()
}

protocol PresenterToRouterProtocol: class {
    static func createModule() -> UIViewController
}
