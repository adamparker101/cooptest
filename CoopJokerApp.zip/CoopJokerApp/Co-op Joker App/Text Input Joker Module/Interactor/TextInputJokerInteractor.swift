//
//  TextInputJokerInteractor.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 10/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit
import Alamofire

class TextInputJokerInteractor: TextInputPresentorToInteractorProtocol {
    
    var presenter: TextInputInteractorToPresenterProtocol?

    func fetchTextFieldJoke(firstName: String, lastName: String) {
          let URL = "http://api.icndb.com/jokes/random?firstName=\(firstName)&?lastName=\(lastName)"
              
              Alamofire.request(URL).response { response in
                  if(response.response?.statusCode == 200){
                      guard let data = response.data else { return }
                      do {
                          let decoder = JSONDecoder()
                          let jokeResponse = try decoder.decode(JokerModel.self, from: data)
                          self.presenter?.jokeFetched(joke: jokeResponse)
                      } catch let error {
                          print(error)
                      }
                  }
                  else {
                     // self.presenter?.jokerFetchedFailed()
                  }
              }
    }
  

}
