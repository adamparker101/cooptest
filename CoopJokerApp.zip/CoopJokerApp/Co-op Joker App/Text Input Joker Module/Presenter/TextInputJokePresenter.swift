//
//  TextInputJokePresenter.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 10/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class TextInputJokePresenter: TextInputViewToPresenterProtocol {
    var view: TextInputPresenterToViewProtocol?
    
    var interactor: TextInputPresentorToInteractorProtocol?
    
    var router: TextInputPresenterToRouterProtocol?
    
    func startFetchingJoke(firstName : String , lastName : String)
    {
        interactor?.fetchTextFieldJoke(firstName: firstName, lastName: lastName)
    }

}

extension TextInputJokePresenter: TextInputInteractorToPresenterProtocol
{
    func jokeFetched(joke: JokerModel) {
        view?.showInputTextJoke(joke: joke)
    }
    
    func jokerFetchedFailed() {
        view?.showError(error: "Problem Fetching Input Joke")
    }

}
