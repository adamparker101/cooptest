//
//  textInputJokeRouter.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 10/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class textInputJokeRouter: TextInputPresenterToRouterProtocol {
    
    class func createModule() ->UIViewController{
        
          let view = mainstoryboard.instantiateViewController(withIdentifier: "TextInputJokeViewController") as? TextInputJokeViewController

              let presenter: TextInputViewToPresenterProtocol & TextInputInteractorToPresenterProtocol = TextInputJokePresenter()
              let interactor: TextInputPresentorToInteractorProtocol = TextInputJokerInteractor()
              let router: TextInputPresenterToRouterProtocol = textInputJokeRouter()
              
              view?.presenter = presenter
              presenter.view = view
              presenter.router = router
              presenter.interactor = interactor
              interactor.presenter = presenter
              
              return view!;

      }
      
      static var mainstoryboard: UIStoryboard{
          return UIStoryboard(name:"Main",bundle: Bundle.main)
      }

}
