//
//  TextInputJokeProtocol.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 10/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit
import Foundation

protocol TextInputPresenterToViewProtocol: class {
    func showInputTextJoke(joke:JokerModel)
    func showError(error: String)
}

protocol TextInputInteractorToPresenterProtocol: class {
    func jokeFetched(joke: JokerModel)
    func jokerFetchedFailed()
}

protocol TextInputPresentorToInteractorProtocol: class {
   var presenter: TextInputInteractorToPresenterProtocol? {get set}
    func fetchTextFieldJoke(firstName: String, lastName: String)
}

protocol TextInputViewToPresenterProtocol: class {
   var view: TextInputPresenterToViewProtocol? {get set}
   var interactor: TextInputPresentorToInteractorProtocol? {get set}
   var router: TextInputPresenterToRouterProtocol? {get set}
   func startFetchingJoke(firstName: String , lastName: String)
}

protocol TextInputPresenterToRouterProtocol: class {
    static func createModule() -> UIViewController
}
