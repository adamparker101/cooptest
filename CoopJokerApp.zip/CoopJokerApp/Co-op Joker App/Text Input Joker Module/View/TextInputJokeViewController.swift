//
//  TextInputJokeViewController.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 10/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit
import Foundation

class TextInputJokeViewController: UIViewController {

    @IBOutlet private weak var searchBtn: UIButton!
    var presenter: TextInputViewToPresenterProtocol?

    @IBOutlet private weak var textField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        styleAllBtns(Btn: searchBtn)
        let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(hideKeyboard))
        self.view.addGestureRecognizer(tapGesture)
        // Do any additional setup after loading the view.
    }
    @objc func hideKeyboard() {
         self.view .endEditing(true)
     }
    
    func styleAllBtns(Btn : UIButton)
       {
           Btn.layer.cornerRadius = 10
           Btn.clipsToBounds = true
       }


    @IBAction func inputJokeSearchAction(_ sender: Any) {
        
        // Code to seperate the first and last name
        let fullNameArr = textField.text?.components(separatedBy: " ")

        if fullNameArr?.count ?? 0 >= 2
        {
            let firstName    = fullNameArr?[0]
            let lastName = fullNameArr?[1]
                      
            // MARK: The API is not returning the correct last name, I have checked this through postman with the same issue.
            presenter?.startFetchingJoke(firstName: firstName ?? "", lastName: lastName ?? "")
        }
        else
        {
            //MARK: show error because there is not a first name and last name
            self.presenter?.view?.showError(error: "You must enter your first and last name, seperated by a space.")
        }
       
     }
}

extension TextInputJokeViewController : TextInputPresenterToViewProtocol {

    func showInputTextJoke(joke: JokerModel) {
        let alert = UIAlertController(title: "Input joke", message: joke.value?.joke , preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Thanks", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
    }
    
    
    func showError(error: String) {
          let alert = UIAlertController(title: "Alert", message: error , preferredStyle: UIAlertController.Style.alert)
          alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
          self.present(alert, animated: true, completion: nil)
      }
    
}
