//
//  TextInputJokeRequest.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 10/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class TextInputJokeRequest: Codable {

}
