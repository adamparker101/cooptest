//
//  NeverEndJokerViewController.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class NeverEndJokerViewController: UIViewController {

    internal var tableViewDataSource: [JokerDetailModel]?
    var presenter: MultiJokerViewToPresenterProtocol?
    @IBOutlet private weak var indicatorView: UIActivityIndicatorView!

    @IBOutlet private weak var tableView: UITableView! {
           didSet {
               tableView.delegate = self
               tableView.dataSource = self
           }
       }
    override func viewDidLoad() {
        super.viewDidLoad()

        presenter?.startFetchingMultipleJokes()
        // Do any additional setup after loading the view.
    }
    


}

extension NeverEndJokerViewController : MultiJokerPresenterToViewProtocol {
    
    
    func showMultipleRandomJoke(joke: [JokerDetailModel]) {
       
        if tableViewDataSource != nil
        {
            self.tableViewDataSource?.append(contentsOf: joke)
        }
        else
        {
            self.tableViewDataSource = joke

        }
        self.tableView.reloadData()
        self.indicatorView.stopAnimating()
        
    }
    
    func showError() {
        let alert = UIAlertController(title: "Alert", message: "Problem Fetching Multiple Jokes", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
}

extension NeverEndJokerViewController: UITableViewDelegate, UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableViewDataSource?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let repo = tableViewDataSource![indexPath.row]
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "subtitle")
        cell.textLabel?.text = repo.joke
        cell.detailTextLabel?.textColor = UIColor.lightGray
        cell.detailTextLabel?.text = repo.joke
        return cell
        
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let visibleLastIndexPath = tableView.visibleCells.compactMap { [weak self] in
            self?.tableView.indexPath(for: $0)
        }.last
        guard let last = visibleLastIndexPath, last.row > (tableViewDataSource?.count ?? 0) - 2 else { return }
        self.indicatorView.startAnimating()
        presenter?.startFetchingMultipleJokes()
    }
}
