//
//  NeverEndingJokeTableViewDataSource.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import Foundation
import UIKit

final class NeverEndingJokeTableViewDataSource: TableViewItemDataSource {

    private var entities: MultiJokerModel!

    init(entities: MultiJokerModel) {
        self.entities = entities
    }

    var numberOfItems: Int {
        return entities.value.count 
    }

    func itemCell(tableView: UITableView, indexPath: IndexPath) -> UITableViewCell {
        
        let value = entities.value[indexPath.row]
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "subtitle")
        cell.textLabel?.text = value.joke
        cell.detailTextLabel?.textColor = UIColor.lightGray
        cell.detailTextLabel?.text = value.joke
        return cell
    }

}
