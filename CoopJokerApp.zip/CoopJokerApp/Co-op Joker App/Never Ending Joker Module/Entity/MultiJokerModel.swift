//
//  MultiJokerModel.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import Foundation

class MultiJokerModel: Codable {

    let type: String?
    var value: [JokerDetailModel] = []
    
    enum CodingKeys: String, CodingKey {
           case type
           case value
    }
}

