//
//  MultiJokerPresenter.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class MultiJokerPresenter: MultiJokerViewToPresenterProtocol {
    
    var view: MultiJokerPresenterToViewProtocol?
    var interactor: MultiJokerPresentorToInteractorProtocol?
    var router: MultiJokerPresenterToRouterProtocol?
    
    func startFetchingMultipleJokes() {
        
        interactor?.fetchMultipleRandomJokes()

    }
}

extension MultiJokerPresenter: MultiJokerInteractorToPresenterProtocol {
    
    func multipleJokesFetched(joke: [JokerDetailModel]) {
        view?.showMultipleRandomJoke(joke: joke)
    }
    
    
    
    func jokerFetchedFailed() {
        view?.showError()
    }

}
