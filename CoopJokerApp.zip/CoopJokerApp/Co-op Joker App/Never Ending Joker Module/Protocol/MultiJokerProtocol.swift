//
//  MultiJokerProtocol.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit
import Foundation

protocol MultiJokerPresenterToViewProtocol: class {
   func showMultipleRandomJoke(joke: [JokerDetailModel])
   func showError()
}

protocol MultiJokerInteractorToPresenterProtocol: class {
   func multipleJokesFetched(joke: [JokerDetailModel])
   func jokerFetchedFailed()
}

protocol MultiJokerPresentorToInteractorProtocol: class {
   var presenter: MultiJokerInteractorToPresenterProtocol? {get set}
   func fetchMultipleRandomJokes()
}

protocol MultiJokerViewToPresenterProtocol: class {
   var view: MultiJokerPresenterToViewProtocol? {get set}
   var interactor: MultiJokerPresentorToInteractorProtocol? {get set}
   var router: MultiJokerPresenterToRouterProtocol? {get set}
   func startFetchingMultipleJokes()
}

protocol MultiJokerPresenterToRouterProtocol: class {
    static func createModuleMulti() -> UIViewController
}

protocol TableViewItemDataSource: AnyObject {
    var numberOfItems: Int { get }

    func itemCell(tableView: UITableView, indexPath: IndexPath) -> UITableViewCell
}

