//
//  MultiJokerInteractor.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import Foundation
import Alamofire

class MultiJokerInteractor: MultiJokerPresentorToInteractorProtocol {

    public static let MULTI_URL = "http://api.icndb.com/jokes/random/20"

     var presenter: MultiJokerInteractorToPresenterProtocol?
     
    func fetchMultipleRandomJokes() {
         
           Alamofire.request(MultiJokerInteractor.MULTI_URL).response { response in
                            if(response.response?.statusCode == 200){
                                guard let data = response.data else { return }
                                do {
                                    let decoder = JSONDecoder()
                                    let jokeResponse = try decoder.decode(MultiJokerModel.self, from: data)
                                    self.presenter?.multipleJokesFetched(joke: jokeResponse.value)
                                } catch let error {
                                    print(error)
                                }
                            }
                            else {
                                self.presenter?.jokerFetchedFailed()
                            }
                        }
     }
    
}
