//
//  MultiJokerRouter.swift
//  Co-op Joker App
//
//  Created by Adam Parker on 09/11/2019.
//  Copyright © 2019 Adam Parker. All rights reserved.
//

import UIKit

class MultiJokerRouter: MultiJokerPresenterToRouterProtocol {

    class func createModuleMulti() ->UIViewController{
        
          let view = mainstoryboard.instantiateViewController(withIdentifier: "NeverEndJokerViewController") as? NeverEndJokerViewController

              let presenter: MultiJokerViewToPresenterProtocol & MultiJokerInteractorToPresenterProtocol = MultiJokerPresenter()
              let interactor: MultiJokerPresentorToInteractorProtocol = MultiJokerInteractor()
              let router: MultiJokerPresenterToRouterProtocol = MultiJokerRouter()
              
              view?.presenter = presenter
              presenter.view = view
              presenter.router = router
              presenter.interactor = interactor
              interactor.presenter = presenter
              
              return view!;

      }
      
      static var mainstoryboard: UIStoryboard{
          return UIStoryboard(name:"Main",bundle: Bundle.main)
      }
    
}
